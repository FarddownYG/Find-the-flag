Keep digging.
