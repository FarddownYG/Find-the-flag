The other file is locked. The password is what malware zips usually use.
